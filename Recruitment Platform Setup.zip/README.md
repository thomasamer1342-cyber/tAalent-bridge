
  # Recruitment Platform Setup

  This is a code bundle for Recruitment Platform Setup. The original project is available at https://www.figma.com/design/eT8wFLCr3HutKaq3pcW5H5/Recruitment-Platform-Setup.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  