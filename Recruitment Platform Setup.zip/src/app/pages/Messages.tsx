import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { ScrollArea } from '../components/ui/scroll-area';
import { MessageSquare, Send } from 'lucide-react';
import { useLocation } from 'react-router';

export default function Messages() {
  const { user } = useAuth();
  const { messages, sendMessage, markMessageAsRead, getAllUsers } = useData();
  const location = useLocation();
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [messageText, setMessageText] = useState('');

  const isCoFounder = user?.role === 'co-founder';
  const allUsers = getAllUsers();

  useEffect(() => {
    if (location.state?.toUserId) {
      setSelectedUserId(location.state.toUserId);
    }
  }, [location.state]);

  if (!user) return null;

  const myMessages = messages.filter(
    m => m.fromUserId === user.id || m.toUserId === user.id
  );

  // Get unique conversations
  const conversations = new Map<string, any>();
  myMessages.forEach(msg => {
    const otherUserId = msg.fromUserId === user.id ? msg.toUserId : msg.fromUserId;
    const otherUserName = msg.fromUserId === user.id ? msg.toName : msg.fromName;

    if (!conversations.has(otherUserId)) {
      const userMessages = myMessages.filter(
        m => m.fromUserId === otherUserId || m.toUserId === otherUserId
      );
      const unreadCount = userMessages.filter(m => m.toUserId === user.id && !m.read).length;
      const lastMessage = userMessages[userMessages.length - 1];

      conversations.set(otherUserId, {
        userId: otherUserId,
        userName: otherUserName,
        unreadCount,
        lastMessage
      });
    }
  });

  const conversationsList = Array.from(conversations.values()).sort(
    (a, b) => new Date(b.lastMessage.createdAt).getTime() - new Date(a.lastMessage.createdAt).getTime()
  );

  // If co-founder and no selected user, add option to message anyone
  const availableUsers = isCoFounder
    ? allUsers.filter(u => u.id !== user.id && u.role !== 'co-founder')
    : [];

  const currentConversation = selectedUserId
    ? myMessages.filter(m => m.fromUserId === selectedUserId || m.toUserId === selectedUserId)
    : [];

  const selectedUser = selectedUserId
    ? conversations.get(selectedUserId) || 
      availableUsers.find(u => u.id === selectedUserId) ||
      { userName: 'Talent Bridge Management' }
    : null;

  useEffect(() => {
    if (selectedUserId) {
      currentConversation
        .filter(m => m.toUserId === user.id && !m.read)
        .forEach(m => markMessageAsRead(m.id));
    }
  }, [selectedUserId, currentConversation.length]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || !selectedUserId) return;

    const toUser = allUsers.find(u => u.id === selectedUserId);
    const toName = toUser?.name || 'Talent Bridge Management';

    sendMessage(selectedUserId, toName, messageText);
    setMessageText('');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">الرسائل</h1>
        <p className="text-white/60">تواصل مع الإدارة والفريق</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-16rem)]">
        {/* Conversations List */}
        <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10 lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-[#60a5fa]" />
              المحادثات
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[calc(100vh-22rem)]">
              <div className="space-y-1 p-4">
                {!isCoFounder && (
                  <button
                    onClick={() => setSelectedUserId('admin')}
                    className={`w-full text-right p-3 rounded-lg transition-colors ${
                      selectedUserId === 'admin'
                        ? 'bg-gradient-to-r from-[#60a5fa]/20 to-[#a78bfa]/20 border border-[#60a5fa]/30'
                        : 'bg-white/5 hover:bg-white/10'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium text-white">Talent Bridge Management</h3>
                        <p className="text-sm text-white/60">الإدارة</p>
                      </div>
                    </div>
                  </button>
                )}

                {isCoFounder && availableUsers.length > 0 && (
                  <div className="mb-4">
                    <p className="text-xs text-white/50 mb-2 px-3">بدء محادثة جديدة</p>
                    <select
                      onChange={(e) => setSelectedUserId(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-lg p-2 text-white text-sm"
                    >
                      <option value="">اختر مستخدم</option>
                      {availableUsers.map(u => (
                        <option key={u.id} value={u.id}>
                          {u.name} ({u.role === 'team-leader' ? 'قائد فريق' : 'موظف'})
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {conversationsList.map(conv => (
                  <button
                    key={conv.userId}
                    onClick={() => setSelectedUserId(conv.userId)}
                    className={`w-full text-right p-3 rounded-lg transition-colors ${
                      selectedUserId === conv.userId
                        ? 'bg-gradient-to-r from-[#60a5fa]/20 to-[#a78bfa]/20 border border-[#60a5fa]/30'
                        : 'bg-white/5 hover:bg-white/10'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-medium text-white">{conv.userName}</h3>
                          {conv.unreadCount > 0 && (
                            <span className="bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                              {conv.unreadCount}
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-white/60 truncate">
                          {conv.lastMessage.message}
                        </p>
                        <p className="text-xs text-white/40 mt-1">
                          {new Date(conv.lastMessage.createdAt).toLocaleDateString('ar-EG', {
                            day: 'numeric',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                      </div>
                    </div>
                  </button>
                ))}

                {conversationsList.length === 0 && !isCoFounder && (
                  <p className="text-center text-white/40 py-8 text-sm">
                    لا توجد محادثات بعد<br />
                    ابدأ محادثة مع الإدارة
                  </p>
                )}

                {conversationsList.length === 0 && isCoFounder && (
                  <p className="text-center text-white/40 py-8 text-sm">
                    لا توجد محادثات بعد
                  </p>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Chat Area */}
        <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10 lg:col-span-2 flex flex-col">
          {selectedUserId ? (
            <>
              <CardHeader className="border-b border-white/10">
                <CardTitle className="text-white">{selectedUser?.userName || 'Talent Bridge Management'}</CardTitle>
                <CardDescription className="text-white/60">
                  {currentConversation.length} رسالة
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-1 p-0">
                <ScrollArea className="h-[calc(100vh-28rem)] p-4">
                  <div className="space-y-4">
                    {currentConversation.map(msg => {
                      const isMyMessage = msg.fromUserId === user.id;

                      return (
                        <div
                          key={msg.id}
                          className={`flex ${isMyMessage ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-[70%] rounded-lg p-3 ${
                              isMyMessage
                                ? 'bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] text-white'
                                : 'bg-white/10 text-white'
                            }`}
                          >
                            <p className="text-sm">{msg.message}</p>
                            <p className={`text-xs mt-1 ${isMyMessage ? 'text-white/80' : 'text-white/50'}`}>
                              {new Date(msg.createdAt).toLocaleDateString('ar-EG', {
                                day: 'numeric',
                                month: 'short',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                    {currentConversation.length === 0 && (
                      <p className="text-center text-white/40 py-8">
                        لا توجد رسائل بعد. ابدأ المحادثة!
                      </p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
              <div className="p-4 border-t border-white/10">
                <form onSubmit={handleSendMessage} className="flex gap-2">
                  <Textarea
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    placeholder="اكتب رسالتك..."
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/40 resize-none min-h-[60px]"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage(e);
                      }
                    }}
                  />
                  <Button
                    type="submit"
                    disabled={!messageText.trim()}
                    className="bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] hover:from-[#3b82f6] hover:to-[#8b5cf6] text-white"
                  >
                    <Send className="h-5 w-5" />
                  </Button>
                </form>
              </div>
            </>
          ) : (
            <CardContent className="flex-1 flex items-center justify-center">
              <div className="text-center text-white/40">
                <MessageSquare className="h-16 w-16 mx-auto mb-4 opacity-50" />
                <p>اختر محادثة لبدء المراسلة</p>
              </div>
            </CardContent>
          )}
        </Card>
      </div>
    </div>
  );
}
