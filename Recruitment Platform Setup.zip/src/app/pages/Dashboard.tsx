import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Users, UserCheck, TrendingUp, Bell, Copy, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';

export default function Dashboard() {
  const { user } = useAuth();
  const { candidates, offers, notifications, markNotificationAsRead, markAllNotificationsAsRead, getAllUsers } = useData();
  const [codeCopied, setCodeCopied] = useState(false);

  if (!user) return null;

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCodeCopied(true);
    setTimeout(() => setCodeCopied(false), 2000);
  };

  const userNotifications = notifications.filter(n => n.userId === user.id);
  const unreadNotifications = userNotifications.filter(n => !n.read);

  if (user.role === 'co-founder') {
    const allUsers = getAllUsers();
    const teamLeaders = allUsers.filter(u => u.role === 'team-leader');
    const recruiters = allUsers.filter(u => u.role === 'recruiter');
    const totalCandidates = candidates.length;
    const acceptedCandidates = candidates.filter(c => c.status === 'accepted').length;

    return (
      <div className="space-y-6">
        {/* Welcome */}
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">مرحباً، {user.name}</h1>
          <p className="text-white/60">لوحة التحكم الرئيسية - Co-Founder</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-[#60a5fa]/20 to-[#3b82f6]/20 border-[#60a5fa]/30">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-white">قادة الفرق</CardTitle>
              <Users className="h-4 w-4 text-[#60a5fa]" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{teamLeaders.length}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-[#a78bfa]/20 to-[#8b5cf6]/20 border-[#a78bfa]/30">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-white">الموظفين</CardTitle>
              <Users className="h-4 w-4 text-[#a78bfa]" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{recruiters.length}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-[#34d399]/20 to-[#10b981]/20 border-[#34d399]/30">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-white">إجمالي المرشحين</CardTitle>
              <UserCheck className="h-4 w-4 text-[#34d399]" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{totalCandidates}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-[#fbbf24]/20 to-[#f59e0b]/20 border-[#fbbf24]/30">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-white">المقبولين</CardTitle>
              <TrendingUp className="h-4 w-4 text-[#fbbf24]" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{acceptedCandidates}</div>
            </CardContent>
          </Card>
        </div>

        {/* Notifications */}
        {unreadNotifications.length > 0 && (
          <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bell className="h-5 w-5 text-[#60a5fa]" />
                  <CardTitle className="text-white">الإشعارات</CardTitle>
                  <Badge className="bg-red-500">{unreadNotifications.length}</Badge>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={markAllNotificationsAsRead}
                  className="text-white/60 hover:text-white"
                >
                  تحديد الكل كمقروء
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {unreadNotifications.slice(0, 5).map(notification => (
                <div
                  key={notification.id}
                  className="flex items-start gap-3 p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
                  onClick={() => markNotificationAsRead(notification.id)}
                >
                  <Bell className="h-4 w-4 text-[#60a5fa] mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm text-white">{notification.message}</p>
                    <p className="text-xs text-white/50 mt-1">
                      {new Date(notification.createdAt).toLocaleDateString('ar-EG', {
                        day: 'numeric',
                        month: 'short',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Team Leaders */}
        <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
          <CardHeader>
            <CardTitle className="text-white">قادة الفرق</CardTitle>
            <CardDescription className="text-white/60">جميع قادة الفرق والأكواد الخاصة بهم</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {teamLeaders.map(leader => {
                const leaderRecruiters = recruiters.filter(r => r.linkedTeamLeaderId === leader.id);
                const leaderCandidates = candidates.filter(c => c.teamLeaderId === leader.id);

                return (
                  <div
                    key={leader.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                  >
                    <div>
                      <h3 className="font-medium text-white">{leader.name}</h3>
                      <p className="text-sm text-white/60">{leader.email}</p>
                      <div className="flex items-center gap-4 mt-2">
                        <span className="text-xs text-white/50">
                          {leaderRecruiters.length} موظف
                        </span>
                        <span className="text-xs text-white/50">
                          {leaderCandidates.length} مرشح
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] font-mono">
                        {leader.teamLeaderCode}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => copyCode(leader.teamLeaderCode!)}
                        className="text-white/60 hover:text-white"
                      >
                        {codeCopied ? <CheckCircle2 className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                );
              })}
              {teamLeaders.length === 0 && (
                <p className="text-center text-white/40 py-8">لا يوجد قادة فرق حتى الآن</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent Candidates */}
        <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
          <CardHeader>
            <CardTitle className="text-white">أحدث المرشحين</CardTitle>
            <CardDescription className="text-white/60">آخر المرشحين المضافين للمنصة</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {candidates.slice(-5).reverse().map(candidate => {
                const recruiter = recruiters.find(r => r.id === candidate.recruiterId);
                const statusColors = {
                  new: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
                  'in-progress': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
                  accepted: 'bg-green-500/20 text-green-400 border-green-500/30',
                  rejected: 'bg-red-500/20 text-red-400 border-red-500/30'
                };

                return (
                  <div
                    key={candidate.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-white/5"
                  >
                    <div>
                      <h3 className="font-medium text-white">{candidate.name}</h3>
                      <p className="text-sm text-white/60">{candidate.position}</p>
                      <p className="text-xs text-white/50 mt-1">بواسطة: {recruiter?.name || 'غير معروف'}</p>
                    </div>
                    <Badge className={statusColors[candidate.status]}>
                      {candidate.status === 'new' && 'جديد'}
                      {candidate.status === 'in-progress' && 'قيد المتابعة'}
                      {candidate.status === 'accepted' && 'مقبول'}
                      {candidate.status === 'rejected' && 'مرفوض'}
                    </Badge>
                  </div>
                );
              })}
              {candidates.length === 0 && (
                <p className="text-center text-white/40 py-8">لا يوجد مرشحين حتى الآن</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (user.role === 'team-leader') {
    const allUsers = getAllUsers();
    const myRecruiters = allUsers.filter(u => u.role === 'recruiter' && u.linkedTeamLeaderId === user.id);
    const myCandidates = candidates.filter(c => c.teamLeaderId === user.id);
    const acceptedCandidates = myCandidates.filter(c => c.status === 'accepted').length;

    return (
      <div className="space-y-6">
        {/* Welcome */}
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">مرحباً، {user.name}</h1>
          <p className="text-white/60">لوحة تحكم قائد الفريق</p>
        </div>

        {/* Team Code */}
        <Card className="bg-gradient-to-r from-[#60a5fa]/20 to-[#a78bfa]/20 border-[#60a5fa]/30">
          <CardHeader>
            <CardTitle className="text-white">كود فريقك</CardTitle>
            <CardDescription className="text-white/60">شارك هذا الكود مع أعضاء فريقك</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3">
              <div className="flex-1 bg-white/10 border border-white/20 rounded-lg px-4 py-3">
                <code className="text-xl font-mono text-white">{user.teamLeaderCode}</code>
              </div>
              <Button
                onClick={() => copyCode(user.teamLeaderCode!)}
                className="bg-white/10 hover:bg-white/20 text-white"
              >
                {codeCopied ? <CheckCircle2 className="h-5 w-5" /> : <Copy className="h-5 w-5" />}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-gradient-to-br from-[#60a5fa]/20 to-[#3b82f6]/20 border-[#60a5fa]/30">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-white">أعضاء الفريق</CardTitle>
              <Users className="h-4 w-4 text-[#60a5fa]" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{myRecruiters.length}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-[#a78bfa]/20 to-[#8b5cf6]/20 border-[#a78bfa]/30">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-white">المرشحين</CardTitle>
              <UserCheck className="h-4 w-4 text-[#a78bfa]" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{myCandidates.length}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-[#34d399]/20 to-[#10b981]/20 border-[#34d399]/30">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-white">المقبولين</CardTitle>
              <TrendingUp className="h-4 w-4 text-[#34d399]" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{acceptedCandidates}</div>
            </CardContent>
          </Card>
        </div>

        {/* Notifications */}
        {unreadNotifications.length > 0 && (
          <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bell className="h-5 w-5 text-[#60a5fa]" />
                  <CardTitle className="text-white">الإشعارات</CardTitle>
                  <Badge className="bg-red-500">{unreadNotifications.length}</Badge>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={markAllNotificationsAsRead}
                  className="text-white/60 hover:text-white"
                >
                  تحديد الكل كمقروء
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {unreadNotifications.slice(0, 5).map(notification => (
                <div
                  key={notification.id}
                  className="flex items-start gap-3 p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
                  onClick={() => markNotificationAsRead(notification.id)}
                >
                  <Bell className="h-4 w-4 text-[#60a5fa] mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm text-white">{notification.message}</p>
                    <p className="text-xs text-white/50 mt-1">
                      {new Date(notification.createdAt).toLocaleDateString('ar-EG', {
                        day: 'numeric',
                        month: 'short',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Team Members */}
        <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
          <CardHeader>
            <CardTitle className="text-white">أعضاء الفريق</CardTitle>
            <CardDescription className="text-white/60">الموظفين المرتبطين بك</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {myRecruiters.map(recruiter => {
                const recruiterCandidates = myCandidates.filter(c => c.recruiterId === recruiter.id);
                const accepted = recruiterCandidates.filter(c => c.status === 'accepted').length;

                return (
                  <div
                    key={recruiter.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                  >
                    <div>
                      <h3 className="font-medium text-white">{recruiter.name}</h3>
                      <p className="text-sm text-white/60">{recruiter.email}</p>
                      <div className="flex items-center gap-4 mt-2">
                        <span className="text-xs text-white/50">
                          {recruiterCandidates.length} مرشح
                        </span>
                        <span className="text-xs text-green-400">
                          {accepted} مقبول
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
              {myRecruiters.length === 0 && (
                <p className="text-center text-white/40 py-8">لا يوجد أعضاء في فريقك بعد</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Recruiter Dashboard
  const myCandidates = candidates.filter(c => c.recruiterId === user.id);
  const acceptedCandidates = myCandidates.filter(c => c.status === 'accepted').length;
  const inProgressCandidates = myCandidates.filter(c => c.status === 'in-progress').length;

  return (
    <div className="space-y-6">
      {/* Welcome */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">مرحباً، {user.name}</h1>
        <p className="text-white/60">لوحة تحكم موظف التوظيف</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-[#60a5fa]/20 to-[#3b82f6]/20 border-[#60a5fa]/30">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-white">إجمالي المرشحين</CardTitle>
            <Users className="h-4 w-4 text-[#60a5fa]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{myCandidates.length}</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-[#fbbf24]/20 to-[#f59e0b]/20 border-[#fbbf24]/30">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-white">قيد المتابعة</CardTitle>
            <TrendingUp className="h-4 w-4 text-[#fbbf24]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{inProgressCandidates}</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-[#34d399]/20 to-[#10b981]/20 border-[#34d399]/30">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-white">المقبولين</CardTitle>
            <UserCheck className="h-4 w-4 text-[#34d399]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{acceptedCandidates}</div>
          </CardContent>
        </Card>
      </div>

      {/* Notifications */}
      {unreadNotifications.length > 0 && (
        <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-[#60a5fa]" />
                <CardTitle className="text-white">الإشعارات</CardTitle>
                <Badge className="bg-red-500">{unreadNotifications.length}</Badge>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={markAllNotificationsAsRead}
                className="text-white/60 hover:text-white"
              >
                تحديد الكل كمقروء
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {unreadNotifications.slice(0, 5).map(notification => (
              <div
                key={notification.id}
                className="flex items-start gap-3 p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
                onClick={() => markNotificationAsRead(notification.id)}
              >
                <Bell className="h-4 w-4 text-[#60a5fa] mt-1 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-sm text-white">{notification.message}</p>
                  <p className="text-xs text-white/50 mt-1">
                    {new Date(notification.createdAt).toLocaleDateString('ar-EG', {
                      day: 'numeric',
                      month: 'short',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* My Candidates */}
      <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
        <CardHeader>
          <CardTitle className="text-white">المرشحين الخاصين بي</CardTitle>
          <CardDescription className="text-white/60">جميع المرشحين الذين قمت بإضافتهم</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {myCandidates.map(candidate => {
              const statusColors = {
                new: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
                'in-progress': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
                accepted: 'bg-green-500/20 text-green-400 border-green-500/30',
                rejected: 'bg-red-500/20 text-red-400 border-red-500/30'
              };

              return (
                <div
                  key={candidate.id}
                  className="flex items-center justify-between p-4 rounded-lg bg-white/5"
                >
                  <div>
                    <h3 className="font-medium text-white">{candidate.name}</h3>
                    <p className="text-sm text-white/60">{candidate.position}</p>
                    <p className="text-xs text-white/50 mt-1">{candidate.phone}</p>
                  </div>
                  <Badge className={statusColors[candidate.status]}>
                    {candidate.status === 'new' && 'جديد'}
                    {candidate.status === 'in-progress' && 'قيد المتابعة'}
                    {candidate.status === 'accepted' && 'مقبول'}
                    {candidate.status === 'rejected' && 'مرفوض'}
                  </Badge>
                </div>
              );
            })}
            {myCandidates.length === 0 && (
              <p className="text-center text-white/40 py-8">لم تضف أي مرشحين بعد</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
