import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useData, Offer } from '../contexts/DataContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Plus, Edit, Trash2, DollarSign } from 'lucide-react';
import { Badge } from '../components/ui/badge';

export default function Offers() {
  const { user } = useAuth();
  const { offers, addOffer, updateOffer, deleteOffer } = useData();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingOffer, setEditingOffer] = useState<Offer | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    category: '',
    commission: '',
    description: ''
  });

  if (!user) return null;

  const isCoFounder = user.role === 'co-founder';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (editingOffer) {
      updateOffer(editingOffer.id, formData);
    } else {
      addOffer(formData);
    }

    setFormData({ title: '', category: '', commission: '', description: '' });
    setEditingOffer(null);
    setIsDialogOpen(false);
  };

  const handleEdit = (offer: Offer) => {
    setEditingOffer(offer);
    setFormData({
      title: offer.title,
      category: offer.category,
      commission: offer.commission,
      description: offer.description
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا الأوفر؟')) {
      deleteOffer(id);
    }
  };

  const groupedOffers = offers.reduce((acc, offer) => {
    if (!acc[offer.category]) {
      acc[offer.category] = [];
    }
    acc[offer.category].push(offer);
    return acc;
  }, {} as Record<string, Offer[]>);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">الأوفرز المتاحة</h1>
          <p className="text-white/60">جميع العروض والفرص المتاحة مع العمولات</p>
        </div>
        {isCoFounder && (
          <Dialog open={isDialogOpen} onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) {
              setEditingOffer(null);
              setFormData({ title: '', category: '', commission: '', description: '' });
            }
          }}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] hover:from-[#3b82f6] hover:to-[#8b5cf6] text-white">
                <Plus className="h-4 w-4 mr-2" />
                إضافة أوفر جديد
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-[#1a1f2e] border-white/10 text-white">
              <DialogHeader>
                <DialogTitle>{editingOffer ? 'تعديل الأوفر' : 'إضافة أوفر جديد'}</DialogTitle>
                <DialogDescription className="text-white/60">
                  {editingOffer ? 'قم بتعديل بيانات الأوفر' : 'أضف أوفر جديد للمنصة'}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">عنوان الأوفر</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                    className="bg-white/5 border-white/10 text-white"
                    placeholder="مثال: موظف كول سنتر"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">الفئة</Label>
                  <Input
                    id="category"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    required
                    className="bg-white/5 border-white/10 text-white"
                    placeholder="مثال: كول سنتر"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="commission">العمولة</Label>
                  <Input
                    id="commission"
                    value={formData.commission}
                    onChange={(e) => setFormData({ ...formData, commission: e.target.value })}
                    required
                    className="bg-white/5 border-white/10 text-white"
                    placeholder="مثال: 500 جنيه"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">الوصف</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    required
                    className="bg-white/5 border-white/10 text-white min-h-24"
                    placeholder="أدخل تفاصيل الأوفر..."
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] hover:from-[#3b82f6] hover:to-[#8b5cf6] text-white"
                >
                  {editingOffer ? 'حفظ التعديلات' : 'إضافة الأوفر'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {offers.length === 0 ? (
        <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
          <CardContent className="py-12">
            <p className="text-center text-white/40">لا توجد أوفرز متاحة حالياً</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {Object.entries(groupedOffers).map(([category, categoryOffers]) => (
            <div key={category}>
              <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                <Badge className="bg-gradient-to-r from-[#60a5fa] to-[#a78bfa]">
                  {category}
                </Badge>
                <span className="text-white/60 text-sm">({categoryOffers.length})</span>
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {categoryOffers.map((offer) => (
                  <Card
                    key={offer.id}
                    className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10 hover:border-white/20 transition-all"
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-white text-lg">{offer.title}</CardTitle>
                          <CardDescription className="text-white/60 mt-1">
                            {offer.category}
                          </CardDescription>
                        </div>
                        {isCoFounder && (
                          <div className="flex gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEdit(offer)}
                              className="text-white/60 hover:text-white hover:bg-white/10"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDelete(offer.id)}
                              className="text-white/60 hover:text-red-400 hover:bg-red-500/10"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p className="text-white/70 text-sm">{offer.description}</p>
                      <div className="flex items-center gap-2 pt-3 border-t border-white/10">
                        <DollarSign className="h-5 w-5 text-green-400" />
                        <span className="text-green-400 font-semibold">{offer.commission}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
