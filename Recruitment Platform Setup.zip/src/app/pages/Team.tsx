import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Users, UserCheck, TrendingUp, Mail, Trash2, Copy, CheckCircle2 } from 'lucide-react';
import { useNavigate } from 'react-router';
import { useState } from 'react';

export default function Team() {
  const { user } = useAuth();
  const { candidates, offers, getAllUsers, deleteUser, sendMessage } = useData();
  const navigate = useNavigate();
  const [codeCopied, setCodeCopied] = useState(false);

  if (!user) return null;

  if (user.role !== 'co-founder' && user.role !== 'team-leader') {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10 max-w-md">
          <CardContent className="pt-6">
            <p className="text-center text-white/60">ليس لديك صلاحية للوصول لهذه الصفحة</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const allUsers = getAllUsers();
  const isCoFounder = user.role === 'co-founder';

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCodeCopied(true);
    setTimeout(() => setCodeCopied(false), 2000);
  };

  const handleDeleteUser = (userId: string, userName: string) => {
    if (confirm(`هل أنت متأكد من حذف المستخدم "${userName}"؟ سيتم حذف جميع بياناته المرتبطة.`)) {
      deleteUser(userId);
    }
  };

  const handleSendMessage = (userId: string, userName: string) => {
    navigate('/messages', { state: { toUserId: userId, toName: userName } });
  };

  if (isCoFounder) {
    const teamLeaders = allUsers.filter(u => u.role === 'team-leader');
    const recruiters = allUsers.filter(u => u.role === 'recruiter');

    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">إدارة الفرق</h1>
          <p className="text-white/60">جميع قادة الفرق والموظفين في المنصة</p>
        </div>

        {/* Team Leaders */}
        <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Users className="h-5 w-5 text-[#60a5fa]" />
              قادة الفرق ({teamLeaders.length})
            </CardTitle>
            <CardDescription className="text-white/60">
              جميع قادة الفرق وفرقهم
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {teamLeaders.map(leader => {
                const leaderRecruiters = recruiters.filter(r => r.linkedTeamLeaderId === leader.id);
                const leaderCandidates = candidates.filter(c => c.teamLeaderId === leader.id);
                const acceptedCandidates = leaderCandidates.filter(c => c.status === 'accepted').length;

                return (
                  <div key={leader.id} className="space-y-3">
                    <div className="flex items-center justify-between p-4 rounded-lg bg-gradient-to-r from-[#60a5fa]/10 to-[#a78bfa]/10 border border-white/10">
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <div>
                            <h3 className="font-semibold text-white text-lg">{leader.name}</h3>
                            <p className="text-sm text-white/60">{leader.email}</p>
                            <div className="flex items-center gap-4 mt-2">
                              <Badge className="bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] font-mono">
                                {leader.teamLeaderCode}
                              </Badge>
                              <span className="text-xs text-white/50">
                                {leaderRecruiters.length} موظف
                              </span>
                              <span className="text-xs text-white/50">
                                {leaderCandidates.length} مرشح
                              </span>
                              <span className="text-xs text-green-400">
                                {acceptedCandidates} مقبول
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => copyCode(leader.teamLeaderCode!)}
                          className="text-white/60 hover:text-white hover:bg-white/10"
                        >
                          {codeCopied ? <CheckCircle2 className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleSendMessage(leader.id, leader.name)}
                          className="text-white/60 hover:text-white hover:bg-white/10"
                        >
                          <Mail className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteUser(leader.id, leader.name)}
                          className="text-white/60 hover:text-red-400 hover:bg-red-500/10"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    {leaderRecruiters.length > 0 && (
                      <div className="ml-8 space-y-2">
                        {leaderRecruiters.map(recruiter => {
                          const recruiterCandidates = leaderCandidates.filter(c => c.recruiterId === recruiter.id);
                          const recruiterAccepted = recruiterCandidates.filter(c => c.status === 'accepted').length;

                          return (
                            <div
                              key={recruiter.id}
                              className="flex items-center justify-between p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                            >
                              <div>
                                <h4 className="font-medium text-white">{recruiter.name}</h4>
                                <p className="text-sm text-white/60">{recruiter.email}</p>
                                <div className="flex items-center gap-3 mt-1">
                                  <span className="text-xs text-white/50">
                                    {recruiterCandidates.length} مرشح
                                  </span>
                                  <span className="text-xs text-green-400">
                                    {recruiterAccepted} مقبول
                                  </span>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleSendMessage(recruiter.id, recruiter.name)}
                                  className="text-white/60 hover:text-white hover:bg-white/10"
                                >
                                  <Mail className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleDeleteUser(recruiter.id, recruiter.name)}
                                  className="text-white/60 hover:text-red-400 hover:bg-red-500/10"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
              {teamLeaders.length === 0 && (
                <p className="text-center text-white/40 py-8">لا يوجد قادة فرق حتى الآن</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Team Leader View
  const myRecruiters = allUsers.filter(u => u.role === 'recruiter' && u.linkedTeamLeaderId === user.id);
  const myCandidates = candidates.filter(c => c.teamLeaderId === user.id);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">فريقي</h1>
        <p className="text-white/60">إدارة أعضاء فريقك ومتابعة أدائهم</p>
      </div>

      {/* Team Code */}
      <Card className="bg-gradient-to-r from-[#60a5fa]/20 to-[#a78bfa]/20 border-[#60a5fa]/30">
        <CardHeader>
          <CardTitle className="text-white">كود فريقك</CardTitle>
          <CardDescription className="text-white/60">شارك هذا الكود مع أعضاء فريقك للانضمام</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-3">
            <div className="flex-1 bg-white/10 border border-white/20 rounded-lg px-4 py-3">
              <code className="text-xl font-mono text-white">{user.teamLeaderCode}</code>
            </div>
            <Button
              onClick={() => copyCode(user.teamLeaderCode!)}
              className="bg-white/10 hover:bg-white/20 text-white"
            >
              {codeCopied ? <CheckCircle2 className="h-5 w-5" /> : <Copy className="h-5 w-5" />}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Team Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-[#60a5fa]/20 to-[#3b82f6]/20 border-[#60a5fa]/30">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-white">أعضاء الفريق</CardTitle>
            <Users className="h-4 w-4 text-[#60a5fa]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{myRecruiters.length}</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-[#a78bfa]/20 to-[#8b5cf6]/20 border-[#a78bfa]/30">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-white">إجمالي المرشحين</CardTitle>
            <UserCheck className="h-4 w-4 text-[#a78bfa]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{myCandidates.length}</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-[#34d399]/20 to-[#10b981]/20 border-[#34d399]/30">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-white">المقبولين</CardTitle>
            <TrendingUp className="h-4 w-4 text-[#34d399]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">
              {myCandidates.filter(c => c.status === 'accepted').length}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Team Members */}
      <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
        <CardHeader>
          <CardTitle className="text-white">أعضاء الفريق</CardTitle>
          <CardDescription className="text-white/60">جميع الموظفين المرتبطين بك</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {myRecruiters.map(recruiter => {
              const recruiterCandidates = myCandidates.filter(c => c.recruiterId === recruiter.id);
              const newCandidates = recruiterCandidates.filter(c => c.status === 'new').length;
              const inProgressCandidates = recruiterCandidates.filter(c => c.status === 'in-progress').length;
              const acceptedCandidates = recruiterCandidates.filter(c => c.status === 'accepted').length;
              const rejectedCandidates = recruiterCandidates.filter(c => c.status === 'rejected').length;

              return (
                <div
                  key={recruiter.id}
                  className="p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-medium text-white text-lg">{recruiter.name}</h3>
                      <p className="text-sm text-white/60">{recruiter.email}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleSendMessage(recruiter.id, recruiter.name)}
                      className="text-white/60 hover:text-white hover:bg-white/10"
                    >
                      <Mail className="h-4 w-4 mr-2" />
                      رسالة
                    </Button>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                    <div className="bg-white/5 rounded-lg p-3">
                      <div className="text-lg font-bold text-white">{recruiterCandidates.length}</div>
                      <p className="text-xs text-white/60">الإجمالي</p>
                    </div>
                    <div className="bg-blue-500/10 rounded-lg p-3">
                      <div className="text-lg font-bold text-blue-400">{newCandidates}</div>
                      <p className="text-xs text-blue-400/80">جديد</p>
                    </div>
                    <div className="bg-yellow-500/10 rounded-lg p-3">
                      <div className="text-lg font-bold text-yellow-400">{inProgressCandidates}</div>
                      <p className="text-xs text-yellow-400/80">متابعة</p>
                    </div>
                    <div className="bg-green-500/10 rounded-lg p-3">
                      <div className="text-lg font-bold text-green-400">{acceptedCandidates}</div>
                      <p className="text-xs text-green-400/80">مقبول</p>
                    </div>
                    <div className="bg-red-500/10 rounded-lg p-3">
                      <div className="text-lg font-bold text-red-400">{rejectedCandidates}</div>
                      <p className="text-xs text-red-400/80">مرفوض</p>
                    </div>
                  </div>
                </div>
              );
            })}
            {myRecruiters.length === 0 && (
              <p className="text-center text-white/40 py-8">
                لا يوجد أعضاء في فريقك بعد. شارك كود فريقك مع الموظفين للانضمام!
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
