import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Eye, EyeOff } from 'lucide-react';
import logo from 'figma:asset/f60ca44f97e718c97b4d6bbf80c296ca0d098479.png';

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [hasCode, setHasCode] = useState<boolean | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [coFounderCode, setCoFounderCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const result = await login(email, password, hasCode ? coFounderCode : undefined);

    setLoading(false);

    if (result.success) {
      navigate('/dashboard');
    } else {
      setError(result.message);
    }
  };

  if (hasCode === null) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#1a1f2e] via-[#1e2235] to-[#252a3f] flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10 text-white">
          <CardHeader className="text-center">
            <img src={logo} alt="Talent Bridge" className="h-20 w-auto mx-auto mb-6" />
            <CardTitle className="text-2xl">مرحباً بك في Talent Bridge</CardTitle>
            <CardDescription className="text-white/60">
              هل لديك كود خاص؟
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={() => setHasCode(true)}
              className="w-full bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] hover:from-[#3b82f6] hover:to-[#8b5cf6] text-white"
            >
              نعم، لدي كود
            </Button>
            <Button
              onClick={() => setHasCode(false)}
              variant="outline"
              className="w-full border-white/20 text-white hover:bg-white/10"
            >
              لا، تسجيل دخول عادي
            </Button>
            <div className="text-center">
              <button
                onClick={() => navigate('/register')}
                className="text-sm text-[#60a5fa] hover:text-[#3b82f6] transition-colors"
              >
                ليس لديك حساب؟ سجل الآن
              </button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a1f2e] via-[#1e2235] to-[#252a3f] flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10 text-white">
        <CardHeader className="text-center">
          <img src={logo} alt="Talent Bridge" className="h-20 w-auto mx-auto mb-6" />
          <CardTitle className="text-2xl">تسجيل الدخول</CardTitle>
          <CardDescription className="text-white/60">
            {hasCode ? 'دخول المدير' : 'دخول الأعضاء'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {hasCode && (
              <div className="space-y-2">
                <Label htmlFor="coFounderCode">كود المدير</Label>
                <Input
                  id="coFounderCode"
                  type="text"
                  value={coFounderCode}
                  onChange={(e) => setCoFounderCode(e.target.value)}
                  required
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                  placeholder="أدخل كود المدير الخاص"
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="email">البريد الإلكتروني</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                placeholder="example@email.com"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">كلمة المرور</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/40 pr-10"
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/60"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {error && (
              <Alert variant="destructive" className="bg-red-500/10 border-red-500/20 text-red-400">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] hover:from-[#3b82f6] hover:to-[#8b5cf6] text-white"
            >
              {loading ? 'جاري التسجيل...' : 'تسجيل الدخول'}
            </Button>

            <div className="flex items-center justify-between text-sm">
              <button
                type="button"
                onClick={() => setHasCode(null)}
                className="text-white/60 hover:text-white transition-colors"
              >
                رجوع
              </button>
              <button
                type="button"
                onClick={() => navigate('/register')}
                className="text-[#60a5fa] hover:text-[#3b82f6] transition-colors"
              >
                إنشاء حساب جديد
              </button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
