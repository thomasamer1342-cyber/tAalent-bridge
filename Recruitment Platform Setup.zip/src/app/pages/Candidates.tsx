import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useData, Candidate } from '../contexts/DataContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Plus, Edit, Trash2, Phone, Briefcase, UserPlus, Filter } from 'lucide-react';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';

export default function Candidates() {
  const { user } = useAuth();
  const { candidates, offers, addCandidate, updateCandidate, deleteCandidate, getAllUsers } = useData();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCandidate, setEditingCandidate] = useState<Candidate | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    position: '',
    source: '',
    status: 'new' as Candidate['status'],
    offerId: ''
  });

  if (!user) return null;

  const isCoFounder = user.role === 'co-founder';
  const isTeamLeader = user.role === 'team-leader';
  const isRecruiter = user.role === 'recruiter';

  let filteredCandidates = candidates;

  if (isRecruiter) {
    filteredCandidates = candidates.filter(c => c.recruiterId === user.id);
  } else if (isTeamLeader) {
    filteredCandidates = candidates.filter(c => c.teamLeaderId === user.id);
  }

  if (filterStatus !== 'all') {
    filteredCandidates = filteredCandidates.filter(c => c.status === filterStatus);
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (editingCandidate) {
      updateCandidate(editingCandidate.id, formData);
    } else {
      const teamLeaderId = isRecruiter
        ? user.linkedTeamLeaderId!
        : isTeamLeader
        ? user.id
        : '';

      addCandidate({
        ...formData,
        recruiterId: isRecruiter ? user.id : editingCandidate?.recruiterId || '',
        teamLeaderId
      });
    }

    setFormData({ name: '', phone: '', position: '', source: '', status: 'new', offerId: '' });
    setEditingCandidate(null);
    setIsDialogOpen(false);
  };

  const handleEdit = (candidate: Candidate) => {
    setEditingCandidate(candidate);
    setFormData({
      name: candidate.name,
      phone: candidate.phone,
      position: candidate.position,
      source: candidate.source,
      status: candidate.status,
      offerId: candidate.offerId || ''
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا المرشح؟')) {
      deleteCandidate(id);
    }
  };

  const allUsers = getAllUsers();

  const getRecruiterName = (recruiterId: string) => {
    const recruiter = allUsers.find(u => u.id === recruiterId);
    return recruiter?.name || 'غير معروف';
  };

  const getOfferTitle = (offerId?: string) => {
    if (!offerId) return 'غير محدد';
    const offer = offers.find(o => o.id === offerId);
    return offer?.title || 'غير محدد';
  };

  const statusColors = {
    new: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    'in-progress': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    accepted: 'bg-green-500/20 text-green-400 border-green-500/30',
    rejected: 'bg-red-500/20 text-red-400 border-red-500/30'
  };

  const statusLabels = {
    new: 'جديد',
    'in-progress': 'قيد المتابعة',
    accepted: 'مقبول',
    rejected: 'مرفوض'
  };

  const stats = {
    total: filteredCandidates.length,
    new: filteredCandidates.filter(c => c.status === 'new').length,
    inProgress: filteredCandidates.filter(c => c.status === 'in-progress').length,
    accepted: filteredCandidates.filter(c => c.status === 'accepted').length,
    rejected: filteredCandidates.filter(c => c.status === 'rejected').length
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">المرشحين</h1>
          <p className="text-white/60">إدارة جميع المرشحين وحالاتهم</p>
        </div>
        {(isRecruiter || isCoFounder) && (
          <Dialog open={isDialogOpen} onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) {
              setEditingCandidate(null);
              setFormData({ name: '', phone: '', position: '', source: '', status: 'new', offerId: '' });
            }
          }}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] hover:from-[#3b82f6] hover:to-[#8b5cf6] text-white">
                <Plus className="h-4 w-4 mr-2" />
                إضافة مرشح جديد
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-[#1a1f2e] border-white/10 text-white max-w-md">
              <DialogHeader>
                <DialogTitle>{editingCandidate ? 'تعديل المرشح' : 'إضافة مرشح جديد'}</DialogTitle>
                <DialogDescription className="text-white/60">
                  {editingCandidate ? 'قم بتعديل بيانات المرشح' : 'أضف مرشح جديد للمنصة'}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">الاسم الكامل</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    className="bg-white/5 border-white/10 text-white"
                    placeholder="أدخل اسم المرشح"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">رقم الهاتف</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                    className="bg-white/5 border-white/10 text-white"
                    placeholder="01xxxxxxxxx"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="position">الوظيفة المطلوبة</Label>
                  <Input
                    id="position"
                    value={formData.position}
                    onChange={(e) => setFormData({ ...formData, position: e.target.value })}
                    required
                    className="bg-white/5 border-white/10 text-white"
                    placeholder="مثال: موظف كول سنتر"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="offerId">الأوفر</Label>
                  <Select
                    value={formData.offerId}
                    onValueChange={(value) => setFormData({ ...formData, offerId: value })}
                  >
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue placeholder="اختر الأوفر (اختياري)" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#1a1f2e] border-white/10 text-white">
                      {offers.map(offer => (
                        <SelectItem key={offer.id} value={offer.id}>
                          {offer.title} - {offer.commission}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="source">المصدر</Label>
                  <Input
                    id="source"
                    value={formData.source}
                    onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                    required
                    className="bg-white/5 border-white/10 text-white"
                    placeholder="مثال: فيسبوك، تويتر، إلخ"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="status">الحالة</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData({ ...formData, status: value as Candidate['status'] })}
                  >
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-[#1a1f2e] border-white/10 text-white">
                      <SelectItem value="new">جديد</SelectItem>
                      <SelectItem value="in-progress">قيد المتابعة</SelectItem>
                      <SelectItem value="accepted">مقبول</SelectItem>
                      <SelectItem value="rejected">مرفوض</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] hover:from-[#3b82f6] hover:to-[#8b5cf6] text-white"
                >
                  {editingCandidate ? 'حفظ التعديلات' : 'إضافة المرشح'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-white">{stats.total}</div>
            <p className="text-xs text-white/60 mt-1">الإجمالي</p>
          </CardContent>
        </Card>
        <Card className="bg-blue-500/10 border-blue-500/30">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-blue-400">{stats.new}</div>
            <p className="text-xs text-blue-400/80 mt-1">جديد</p>
          </CardContent>
        </Card>
        <Card className="bg-yellow-500/10 border-yellow-500/30">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-yellow-400">{stats.inProgress}</div>
            <p className="text-xs text-yellow-400/80 mt-1">قيد المتابعة</p>
          </CardContent>
        </Card>
        <Card className="bg-green-500/10 border-green-500/30">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-green-400">{stats.accepted}</div>
            <p className="text-xs text-green-400/80 mt-1">مقبول</p>
          </CardContent>
        </Card>
        <Card className="bg-red-500/10 border-red-500/30">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-red-400">{stats.rejected}</div>
            <p className="text-xs text-red-400/80 mt-1">مرفوض</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
        <CardContent className="pt-6">
          <Tabs value={filterStatus} onValueChange={setFilterStatus}>
            <TabsList className="bg-white/5">
              <TabsTrigger value="all">الكل</TabsTrigger>
              <TabsTrigger value="new">جديد</TabsTrigger>
              <TabsTrigger value="in-progress">قيد المتابعة</TabsTrigger>
              <TabsTrigger value="accepted">مقبول</TabsTrigger>
              <TabsTrigger value="rejected">مرفوض</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardContent>
      </Card>

      {/* Candidates List */}
      <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
        <CardHeader>
          <CardTitle className="text-white">قائمة المرشحين</CardTitle>
          <CardDescription className="text-white/60">
            {filteredCandidates.length} مرشح
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredCandidates.length === 0 ? (
            <p className="text-center text-white/40 py-8">لا يوجد مرشحين</p>
          ) : (
            <div className="space-y-3">
              {filteredCandidates.map((candidate) => (
                <div
                  key={candidate.id}
                  className="flex items-center justify-between p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-start gap-3">
                      <div className="flex-1">
                        <h3 className="font-medium text-white">{candidate.name}</h3>
                        <div className="flex flex-wrap items-center gap-3 mt-2 text-sm text-white/60">
                          <span className="flex items-center gap-1">
                            <Phone className="h-3 w-3" />
                            {candidate.phone}
                          </span>
                          <span className="flex items-center gap-1">
                            <Briefcase className="h-3 w-3" />
                            {candidate.position}
                          </span>
                          {(isCoFounder || isTeamLeader) && (
                            <span className="flex items-center gap-1">
                              <UserPlus className="h-3 w-3" />
                              {getRecruiterName(candidate.recruiterId)}
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge variant="outline" className="text-xs border-white/20 text-white/60">
                            {getOfferTitle(candidate.offerId)}
                          </Badge>
                          <Badge variant="outline" className="text-xs border-white/20 text-white/60">
                            {candidate.source}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={statusColors[candidate.status]}>
                          {statusLabels[candidate.status]}
                        </Badge>
                        {(isRecruiter || isCoFounder) && (
                          <div className="flex gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEdit(candidate)}
                              className="text-white/60 hover:text-white hover:bg-white/10"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDelete(candidate.id)}
                              className="text-white/60 hover:text-red-400 hover:bg-red-500/10"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
