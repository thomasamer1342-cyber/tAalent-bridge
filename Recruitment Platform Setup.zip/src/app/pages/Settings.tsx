import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Badge } from '../components/ui/badge';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Settings as SettingsIcon, UserPlus, Copy, CheckCircle2, Trash2 } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';

const CO_FOUNDER_CODE = 'T9@vQ7#Lm2!Rx84';

export default function Settings() {
  const { user } = useAuth();
  const { getAllUsers, deleteUser } = useData();
  const [isAddCeoDialogOpen, setIsAddCeoDialogOpen] = useState(false);
  const [ceoEmail, setCeoEmail] = useState('');
  const [ceoPassword, setCeoPassword] = useState('');
  const [ceoName, setCeoName] = useState('');
  const [message, setMessage] = useState('');
  const [codeCopied, setCodeCopied] = useState(false);

  if (!user || user.role !== 'co-founder') {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10 max-w-md">
          <CardContent className="pt-6">
            <p className="text-center text-white/60">ليس لديك صلاحية للوصول لهذه الصفحة</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const allUsers = getAllUsers();
  const coFounders = allUsers.filter(u => u.role === 'co-founder');

  const copyCode = () => {
    navigator.clipboard.writeText(CO_FOUNDER_CODE);
    setCodeCopied(true);
    setTimeout(() => setCodeCopied(false), 2000);
  };

  const handleAddCeo = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage('');

    if (allUsers.some(u => u.email === ceoEmail)) {
      setMessage('هذا البريد الإلكتروني مستخدم بالفعل');
      return;
    }

    const newCeo = {
      id: `user-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      email: ceoEmail,
      name: ceoName,
      role: 'co-founder' as const,
      createdAt: new Date().toISOString()
    };

    const users = JSON.parse(localStorage.getItem('talentBridge_users') || '[]');
    users.push(newCeo);
    localStorage.setItem('talentBridge_users', JSON.stringify(users));

    const passwords = JSON.parse(localStorage.getItem('talentBridge_passwords') || '{}');
    passwords[newCeo.id] = ceoPassword;
    localStorage.setItem('talentBridge_passwords', JSON.stringify(passwords));

    setMessage('تم إضافة CEO جديد بنجاح');
    setCeoEmail('');
    setCeoPassword('');
    setCeoName('');
    setIsAddCeoDialogOpen(false);

    setTimeout(() => {
      window.location.reload();
    }, 1500);
  };

  const handleDeleteCeo = (ceoId: string, ceoName: string) => {
    if (ceoId === user.id) {
      alert('لا يمكنك حذف حسابك الخاص');
      return;
    }

    if (confirm(`هل أنت متأكد من حذف CEO "${ceoName}"؟`)) {
      deleteUser(ceoId);
      setMessage('تم حذف CEO بنجاح');
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">الإعدادات</h1>
        <p className="text-white/60">إدارة إعدادات المنصة والصلاحيات</p>
      </div>

      {message && (
        <Alert className="bg-green-500/10 border-green-500/20 text-green-400">
          <AlertDescription>{message}</AlertDescription>
        </Alert>
      )}

      {/* Co-Founder Code */}
      <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
        <CardHeader>
          <div className="flex items-center gap-2">
            <SettingsIcon className="h-5 w-5 text-[#60a5fa]" />
            <CardTitle className="text-white">كود المدير</CardTitle>
          </div>
          <CardDescription className="text-white/60">
            الكود الخاص لإضافة مدراء جدد للمنصة
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex-1 bg-gradient-to-r from-[#60a5fa]/10 to-[#a78bfa]/10 border border-white/20 rounded-lg px-4 py-3">
                <code className="text-lg font-mono text-white">{CO_FOUNDER_CODE}</code>
              </div>
              <Button
                onClick={copyCode}
                className="bg-white/10 hover:bg-white/20 text-white"
              >
                {codeCopied ? <CheckCircle2 className="h-5 w-5" /> : <Copy className="h-5 w-5" />}
              </Button>
            </div>
            <Alert className="bg-yellow-500/10 border-yellow-500/20 text-yellow-400">
              <AlertDescription className="text-sm">
                ⚠️ هذا الكود سري للغاية! لا تشاركه إلا مع من تثق بهم تماماً. يمنح حامله صلاحيات كاملة على المنصة.
              </AlertDescription>
            </Alert>
          </div>
        </CardContent>
      </Card>

      {/* Co-Founders Management */}
      <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <UserPlus className="h-5 w-5 text-[#60a5fa]" />
                <CardTitle className="text-white">المدراء</CardTitle>
              </div>
              <CardDescription className="text-white/60 mt-1">
                جميع المدراء الذين لديهم صلاحيات كاملة على المنصة
              </CardDescription>
            </div>
            <Dialog open={isAddCeoDialogOpen} onOpenChange={setIsAddCeoDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] hover:from-[#3b82f6] hover:to-[#8b5cf6] text-white">
                  <UserPlus className="h-4 w-4 mr-2" />
                  إضافة CEO
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-[#1a1f2e] border-white/10 text-white">
                <DialogHeader>
                  <DialogTitle>إضافة CEO جديد</DialogTitle>
                  <DialogDescription className="text-white/60">
                    أضف مدير تنفيذي جديد للمنصة بصلاحيات كاملة
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleAddCeo} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="ceoName">الاسم الكامل</Label>
                    <Input
                      id="ceoName"
                      value={ceoName}
                      onChange={(e) => setCeoName(e.target.value)}
                      required
                      className="bg-white/5 border-white/10 text-white"
                      placeholder="أدخل اسم المدير"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="ceoEmail">البريد الإلكتروني</Label>
                    <Input
                      id="ceoEmail"
                      type="email"
                      value={ceoEmail}
                      onChange={(e) => setCeoEmail(e.target.value)}
                      required
                      className="bg-white/5 border-white/10 text-white"
                      placeholder="example@email.com"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="ceoPassword">كلمة المرور</Label>
                    <Input
                      id="ceoPassword"
                      type="password"
                      value={ceoPassword}
                      onChange={(e) => setCeoPassword(e.target.value)}
                      required
                      className="bg-white/5 border-white/10 text-white"
                      placeholder="••••••••"
                    />
                  </div>

                  <Alert className="bg-blue-500/10 border-blue-500/20 text-blue-400">
                    <AlertDescription className="text-sm">
                      سيحتاج CEO الجديد لاستخدام كود المدير ({CO_FOUNDER_CODE}) عند تسجيل الدخول
                    </AlertDescription>
                  </Alert>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] hover:from-[#3b82f6] hover:to-[#8b5cf6] text-white"
                  >
                    إضافة CEO
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {coFounders.map(ceo => (
              <div
                key={ceo.id}
                className="flex items-center justify-between p-4 rounded-lg bg-gradient-to-r from-[#60a5fa]/10 to-[#a78bfa]/10 border border-white/10"
              >
                <div>
                  <h3 className="font-semibold text-white">{ceo.name}</h3>
                  <p className="text-sm text-white/60">{ceo.email}</p>
                  {ceo.id === user.id && (
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30 mt-2">
                      أنت
                    </Badge>
                  )}
                </div>
                {ceo.id !== user.id && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDeleteCeo(ceo.id, ceo.name)}
                    className="text-white/60 hover:text-red-400 hover:bg-red-500/10"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Platform Info */}
      <Card className="bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10">
        <CardHeader>
          <CardTitle className="text-white">معلومات المنصة</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between p-3 rounded-lg bg-white/5">
            <span className="text-white/60">اسم المنصة</span>
            <span className="text-white font-medium">Talent Bridge</span>
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg bg-white/5">
            <span className="text-white/60">الإيميل الرسمي</span>
            <span className="text-white font-medium">{user.email}</span>
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg bg-white/5">
            <span className="text-white/60">عدد المستخدمين</span>
            <span className="text-white font-medium">{allUsers.length}</span>
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg bg-white/5">
            <span className="text-white/60">رابط المنصة</span>
            <span className="text-white font-medium text-sm">{window.location.origin}</span>
          </div>
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card className="bg-gradient-to-br from-[#60a5fa]/10 to-[#a78bfa]/10 border-[#60a5fa]/30">
        <CardHeader>
          <CardTitle className="text-white">📋 تعليمات الاستخدام</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-white/80 text-sm">
          <div className="p-3 rounded-lg bg-white/5">
            <strong className="text-white">1. إضافة الأوفرز:</strong>
            <p className="mt-1">انتقل إلى صفحة "الأوفرز" واضغط على "إضافة أوفر جديد". يمكنك إضافة عدة أوفرز لنفس الفئة (مثل: كول سنتر).</p>
          </div>
          <div className="p-3 rounded-lg bg-white/5">
            <strong className="text-white">2. حذف مستخدمين:</strong>
            <p className="mt-1">من صفحة "الفريق"، يمكنك حذف أي Team Leader أو Recruiter. سيتم حذف جميع بياناتهم تلقائياً.</p>
          </div>
          <div className="p-3 rounded-lg bg-white/5">
            <strong className="text-white">3. رابط التسجيل:</strong>
            <p className="mt-1">شارك رابط المنصة مع فريقك: <code className="bg-white/10 px-2 py-1 rounded">{window.location.origin}</code></p>
          </div>
          <div className="p-3 rounded-lg bg-white/5">
            <strong className="text-white">4. إضافة CEO:</strong>
            <p className="mt-1">يمكنك إضافة مدراء آخرين باستخدام نفس كود المدير. سيكون لهم نفس صلاحياتك.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
