import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useAuth, UserRole } from '../contexts/AuthContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Eye, EyeOff, CheckCircle } from 'lucide-react';
import logo from 'figma:asset/f60ca44f97e718c97b4d6bbf80c296ca0d098479.png';

export default function Register() {
  const navigate = useNavigate();
  const { register } = useAuth();
  const [hasCode, setHasCode] = useState<boolean | null>(null);
  const [step, setStep] = useState<'choice' | 'form' | 'success'>('choice');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: '' as UserRole,
    teamLeaderCode: '',
    coFounderCode: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [generatedCode, setGeneratedCode] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError('كلمتا المرور غير متطابقتين');
      return;
    }

    if (!hasCode && !formData.role) {
      setError('يرجى اختيار الدور');
      return;
    }

    if (formData.role === 'recruiter' && !formData.teamLeaderCode) {
      setError('يرجى إدخال كود قائد الفريق');
      return;
    }

    setLoading(true);

    const result = await register({
      name: formData.name,
      email: formData.email,
      password: formData.password,
      role: formData.role,
      teamLeaderCode: formData.role === 'recruiter' ? formData.teamLeaderCode : undefined,
      coFounderCode: hasCode ? formData.coFounderCode : undefined
    });

    setLoading(false);

    if (result.success) {
      if (result.user?.teamLeaderCode) {
        setGeneratedCode(result.user.teamLeaderCode);
      }
      setStep('success');
      setTimeout(() => {
        navigate('/dashboard');
      }, 5000);
    } else {
      setError(result.message);
    }
  };

  if (step === 'choice') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#1a1f2e] via-[#1e2235] to-[#252a3f] flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10 text-white">
          <CardHeader className="text-center">
            <img src={logo} alt="Talent Bridge" className="h-20 w-auto mx-auto mb-6" />
            <CardTitle className="text-2xl">إنشاء حساب جديد</CardTitle>
            <CardDescription className="text-white/60">
              هل لديك كود خاص؟
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={() => {
                setHasCode(true);
                setStep('form');
              }}
              className="w-full bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] hover:from-[#3b82f6] hover:to-[#8b5cf6] text-white"
            >
              نعم، لدي كود مدير
            </Button>
            <Button
              onClick={() => {
                setHasCode(false);
                setStep('form');
              }}
              variant="outline"
              className="w-full border-white/20 text-white hover:bg-white/10"
            >
              لا، تسجيل عادي
            </Button>
            <div className="text-center">
              <button
                onClick={() => navigate('/login')}
                className="text-sm text-[#60a5fa] hover:text-[#3b82f6] transition-colors"
              >
                لديك حساب بالفعل؟ سجل دخولك
              </button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'success') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#1a1f2e] via-[#1e2235] to-[#252a3f] flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10 text-white">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <CheckCircle className="h-16 w-16 text-green-400" />
            </div>
            <CardTitle className="text-2xl">تم التسجيل بنجاح!</CardTitle>
            <CardDescription className="text-white/60">
              مرحباً بك في Talent Bridge
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {generatedCode && (
              <div className="bg-white/5 border border-white/10 rounded-lg p-4">
                <p className="text-sm text-white/60 mb-2">كود قائد الفريق الخاص بك:</p>
                <div className="bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] text-white text-center py-3 px-4 rounded-lg font-mono text-lg">
                  {generatedCode}
                </div>
                <p className="text-xs text-white/50 mt-2">
                  احفظ هذا الكود! سيحتاجه أعضاء فريقك للتسجيل معك
                </p>
              </div>
            )}
            <p className="text-center text-white/60 text-sm">
              سيتم توجيهك تلقائياً خلال 5 ثوانٍ...
            </p>
            <Button
              onClick={() => navigate('/dashboard')}
              className="w-full bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] hover:from-[#3b82f6] hover:to-[#8b5cf6] text-white"
            >
              الذهاب إلى لوحة التحكم
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a1f2e] via-[#1e2235] to-[#252a3f] flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-[#1a1f2e]/50 backdrop-blur-lg border-white/10 text-white">
        <CardHeader className="text-center">
          <img src={logo} alt="Talent Bridge" className="h-20 w-auto mx-auto mb-6" />
          <CardTitle className="text-2xl">إنشاء حساب جديد</CardTitle>
          <CardDescription className="text-white/60">
            {hasCode ? 'تسجيل كمدير' : 'تسجيل كعضو في الفريق'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {hasCode && (
              <div className="space-y-2">
                <Label htmlFor="coFounderCode">كود المدير</Label>
                <Input
                  id="coFounderCode"
                  type="text"
                  value={formData.coFounderCode}
                  onChange={(e) => setFormData({ ...formData, coFounderCode: e.target.value })}
                  required
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                  placeholder="أدخل كود المدير الخاص"
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="name">الاسم الكامل</Label>
              <Input
                id="name"
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                placeholder="أدخل اسمك الكامل"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">البريد الإلكتروني</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                placeholder="example@email.com"
              />
            </div>

            {!hasCode && (
              <div className="space-y-2">
                <Label htmlFor="role">الدور</Label>
                <Select
                  value={formData.role}
                  onValueChange={(value) => setFormData({ ...formData, role: value as UserRole })}
                  required
                >
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue placeholder="اختر دورك" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1f2e] border-white/10 text-white">
                    <SelectItem value="team-leader">قائد فريق</SelectItem>
                    <SelectItem value="recruiter">موظف توظيف</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            {formData.role === 'recruiter' && (
              <div className="space-y-2">
                <Label htmlFor="teamLeaderCode">كود قائد الفريق</Label>
                <Input
                  id="teamLeaderCode"
                  type="text"
                  value={formData.teamLeaderCode}
                  onChange={(e) => setFormData({ ...formData, teamLeaderCode: e.target.value })}
                  required
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                  placeholder="أدخل كود قائد الفريق"
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="password">كلمة المرور</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  required
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/40 pr-10"
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/60"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">تأكيد كلمة المرور</Label>
              <Input
                id="confirmPassword"
                type={showPassword ? 'text' : 'password'}
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                required
                className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                placeholder="••••••••"
              />
            </div>

            {error && (
              <Alert variant="destructive" className="bg-red-500/10 border-red-500/20 text-red-400">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-[#60a5fa] to-[#a78bfa] hover:from-[#3b82f6] hover:to-[#8b5cf6] text-white"
            >
              {loading ? 'جاري التسجيل...' : 'إنشاء الحساب'}
            </Button>

            <div className="flex items-center justify-between text-sm">
              <button
                type="button"
                onClick={() => setStep('choice')}
                className="text-white/60 hover:text-white transition-colors"
              >
                رجوع
              </button>
              <button
                type="button"
                onClick={() => navigate('/login')}
                className="text-[#60a5fa] hover:text-[#3b82f6] transition-colors"
              >
                لديك حساب؟ سجل دخولك
              </button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
