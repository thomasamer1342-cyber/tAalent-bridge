import { Outlet, useNavigate, useLocation } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { useEffect } from 'react';
import { Bell, MessageSquare, LogOut, Menu, X } from 'lucide-react';
import { Button } from './ui/button';
import { useState } from 'react';
import logo from 'figma:asset/f60ca44f97e718c97b4d6bbf80c296ca0d098479.png';

export default function Layout() {
  const { user, logout } = useAuth();
  const { notifications } = useData();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    if (!user && location.pathname !== '/login' && location.pathname !== '/register' && location.pathname !== '/') {
      navigate('/login');
    }
  }, [user, location, navigate]);

  const isAuthPage = location.pathname === '/login' || location.pathname === '/register' || location.pathname === '/';

  if (isAuthPage) {
    return <Outlet />;
  }

  if (!user) {
    return null;
  }

  const unreadNotifications = notifications.filter(n => n.userId === user.id && !n.read).length;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    { label: 'الرئيسية', path: '/dashboard', roles: ['co-founder', 'team-leader', 'recruiter'] },
    { label: 'الأوفرز', path: '/offers', roles: ['co-founder', 'team-leader', 'recruiter'] },
    { label: 'المرشحين', path: '/candidates', roles: ['co-founder', 'team-leader', 'recruiter'] },
    { label: 'الفريق', path: '/team', roles: ['co-founder', 'team-leader'] },
    { label: 'الرسائل', path: '/messages', roles: ['co-founder', 'team-leader', 'recruiter'] },
    { label: 'الإعدادات', path: '/settings', roles: ['co-founder'] }
  ];

  const filteredNavItems = navItems.filter(item => item.roles.includes(user.role));

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a1f2e] via-[#1e2235] to-[#252a3f]">
      {/* Header */}
      <header className="bg-[#1a1f2e]/80 backdrop-blur-lg border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <img src={logo} alt="Talent Bridge" className="h-10 w-auto" />
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-6">
              {filteredNavItems.map(item => (
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className={`text-sm transition-colors ${
                    location.pathname === item.path
                      ? 'text-[#60a5fa] font-medium'
                      : 'text-white/70 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate('/messages')}
                className="relative text-white/70 hover:text-white hover:bg-white/10"
              >
                <MessageSquare className="h-5 w-5" />
              </Button>

              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate('/dashboard')}
                className="relative text-white/70 hover:text-white hover:bg-white/10"
              >
                <Bell className="h-5 w-5" />
                {unreadNotifications > 0 && (
                  <span className="absolute top-1 right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                    {unreadNotifications}
                  </span>
                )}
              </Button>

              <Button
                variant="ghost"
                size="icon"
                onClick={handleLogout}
                className="text-white/70 hover:text-white hover:bg-white/10"
              >
                <LogOut className="h-5 w-5" />
              </Button>

              {/* Mobile Menu Button */}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden text-white/70 hover:text-white hover:bg-white/10"
              >
                {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </div>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <nav className="md:hidden py-4 border-t border-white/10">
              {filteredNavItems.map(item => (
                <button
                  key={item.path}
                  onClick={() => {
                    navigate(item.path);
                    setMobileMenuOpen(false);
                  }}
                  className={`block w-full text-right px-4 py-2 text-sm transition-colors ${
                    location.pathname === item.path
                      ? 'text-[#60a5fa] font-medium bg-white/5'
                      : 'text-white/70 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Outlet />
      </main>
    </div>
  );
}
