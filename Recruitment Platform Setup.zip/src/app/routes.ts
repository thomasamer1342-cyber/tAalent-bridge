import { createBrowserRouter } from 'react-router';
import Layout from './components/Layout';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Offers from './pages/Offers';
import Candidates from './pages/Candidates';
import Team from './pages/Team';
import Messages from './pages/Messages';
import Settings from './pages/Settings';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Layout,
    children: [
      { index: true, Component: Login },
      { path: 'login', Component: Login },
      { path: 'register', Component: Register },
      { path: 'dashboard', Component: Dashboard },
      { path: 'offers', Component: Offers },
      { path: 'candidates', Component: Candidates },
      { path: 'team', Component: Team },
      { path: 'messages', Component: Messages },
      { path: 'settings', Component: Settings }
    ]
  }
]);
