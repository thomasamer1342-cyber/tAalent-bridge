import React, { createContext, useContext, useState, useEffect } from 'react';

export type UserRole = 'co-founder' | 'team-leader' | 'recruiter';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  teamLeaderCode?: string;
  linkedTeamLeaderId?: string;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string, coFounderCode?: string) => Promise<{ success: boolean; message: string }>;
  register: (data: {
    email: string;
    password: string;
    name: string;
    role: UserRole;
    teamLeaderCode?: string;
    coFounderCode?: string;
  }) => Promise<{ success: boolean; message: string; user?: User }>;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const CO_FOUNDER_CODE = 'T9@vQ7#Lm2!Rx84';
const CO_FOUNDER_EMAIL = 'thomasamir333f@gmail.com';

function generateTeamLeaderCode(name: string): string {
  const prefix = name.substring(0, 2).toUpperCase();
  const random = Math.floor(100000 + Math.random() * 900000);
  return `${prefix}${random}`;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loginAttempts, setLoginAttempts] = useState<{ count: number; timestamp: number }>({ count: 0, timestamp: 0 });

  useEffect(() => {
    const storedUser = localStorage.getItem('talentBridge_currentUser');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }

    const attempts = localStorage.getItem('talentBridge_loginAttempts');
    if (attempts) {
      setLoginAttempts(JSON.parse(attempts));
    }
  }, []);

  const checkLoginAttempts = (): boolean => {
    const now = Date.now();
    if (loginAttempts.count >= 7 && now - loginAttempts.timestamp < 24 * 60 * 60 * 1000) {
      return false;
    }
    if (now - loginAttempts.timestamp >= 24 * 60 * 60 * 1000) {
      setLoginAttempts({ count: 0, timestamp: now });
      localStorage.setItem('talentBridge_loginAttempts', JSON.stringify({ count: 0, timestamp: now }));
    }
    return true;
  };

  const incrementLoginAttempts = () => {
    const newAttempts = { count: loginAttempts.count + 1, timestamp: Date.now() };
    setLoginAttempts(newAttempts);
    localStorage.setItem('talentBridge_loginAttempts', JSON.stringify(newAttempts));
  };

  const login = async (email: string, password: string, coFounderCode?: string): Promise<{ success: boolean; message: string }> => {
    if (!checkLoginAttempts()) {
      return { success: false, message: 'تم حظر تسجيل الدخول لمدة 24 ساعة بعد 7 محاولات فاشلة' };
    }

    const users = JSON.parse(localStorage.getItem('talentBridge_users') || '[]');
    
    if (coFounderCode) {
      if (coFounderCode !== CO_FOUNDER_CODE || email !== CO_FOUNDER_EMAIL) {
        incrementLoginAttempts();
        return { success: false, message: 'كود المدير أو البريد الإلكتروني غير صحيح' };
      }
      
      let coFounderUser = users.find((u: User) => u.email === CO_FOUNDER_EMAIL && u.role === 'co-founder');
      if (!coFounderUser) {
        coFounderUser = {
          id: 'co-founder-1',
          email: CO_FOUNDER_EMAIL,
          name: 'Thomas Amir',
          role: 'co-founder',
          createdAt: new Date().toISOString()
        };
        users.push(coFounderUser);
        localStorage.setItem('talentBridge_users', JSON.stringify(users));
      }
      
      setUser(coFounderUser);
      localStorage.setItem('talentBridge_currentUser', JSON.stringify(coFounderUser));
      setLoginAttempts({ count: 0, timestamp: Date.now() });
      localStorage.removeItem('talentBridge_loginAttempts');
      return { success: true, message: 'تم تسجيل الدخول بنجاح' };
    }

    const foundUser = users.find((u: User) => u.email === email && u.role !== 'co-founder');
    if (!foundUser) {
      incrementLoginAttempts();
      return { success: false, message: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' };
    }

    const passwords = JSON.parse(localStorage.getItem('talentBridge_passwords') || '{}');
    if (passwords[foundUser.id] !== password) {
      incrementLoginAttempts();
      return { success: false, message: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' };
    }

    setUser(foundUser);
    localStorage.setItem('talentBridge_currentUser', JSON.stringify(foundUser));
    setLoginAttempts({ count: 0, timestamp: Date.now() });
    localStorage.removeItem('talentBridge_loginAttempts');
    return { success: true, message: 'تم تسجيل الدخول بنجاح' };
  };

  const register = async (data: {
    email: string;
    password: string;
    name: string;
    role: UserRole;
    teamLeaderCode?: string;
    coFounderCode?: string;
  }): Promise<{ success: boolean; message: string; user?: User }> => {
    if (data.coFounderCode) {
      if (data.coFounderCode !== CO_FOUNDER_CODE || data.email !== CO_FOUNDER_EMAIL) {
        return { success: false, message: 'كود المدير أو البريد الإلكتروني غير صحيح' };
      }
      data.role = 'co-founder';
    }

    const users = JSON.parse(localStorage.getItem('talentBridge_users') || '[]');
    
    if (users.some((u: User) => u.email === data.email)) {
      return { success: false, message: 'البريد الإلكتروني مستخدم بالفعل' };
    }

    if (data.role === 'recruiter' && data.teamLeaderCode) {
      const teamLeader = users.find((u: User) => u.teamLeaderCode === data.teamLeaderCode && u.role === 'team-leader');
      if (!teamLeader) {
        return { success: false, message: 'كود قائد الفريق غير صحيح' };
      }
    }

    const newUser: User = {
      id: `user-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      email: data.email,
      name: data.name,
      role: data.role,
      createdAt: new Date().toISOString()
    };

    if (data.role === 'team-leader') {
      newUser.teamLeaderCode = generateTeamLeaderCode(data.name);
    }

    if (data.role === 'recruiter' && data.teamLeaderCode) {
      const teamLeader = users.find((u: User) => u.teamLeaderCode === data.teamLeaderCode);
      newUser.linkedTeamLeaderId = teamLeader.id;
    }

    users.push(newUser);
    localStorage.setItem('talentBridge_users', JSON.stringify(users));

    const passwords = JSON.parse(localStorage.getItem('talentBridge_passwords') || '{}');
    passwords[newUser.id] = data.password;
    localStorage.setItem('talentBridge_passwords', JSON.stringify(passwords));

    setUser(newUser);
    localStorage.setItem('talentBridge_currentUser', JSON.stringify(newUser));

    return { success: true, message: 'تم التسجيل بنجاح', user: newUser };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('talentBridge_currentUser');
  };

  const updateUser = (updates: Partial<User>) => {
    if (!user) return;

    const updatedUser = { ...user, ...updates };
    setUser(updatedUser);
    localStorage.setItem('talentBridge_currentUser', JSON.stringify(updatedUser));

    const users = JSON.parse(localStorage.getItem('talentBridge_users') || '[]');
    const index = users.findIndex((u: User) => u.id === user.id);
    if (index !== -1) {
      users[index] = updatedUser;
      localStorage.setItem('talentBridge_users', JSON.stringify(users));
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
