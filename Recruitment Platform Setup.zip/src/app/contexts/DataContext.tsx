import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

export interface Candidate {
  id: string;
  name: string;
  phone: string;
  position: string;
  source: string;
  status: 'new' | 'in-progress' | 'accepted' | 'rejected';
  recruiterId: string;
  teamLeaderId: string;
  offerId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Offer {
  id: string;
  title: string;
  category: string;
  commission: string;
  description: string;
  createdAt: string;
}

export interface Message {
  id: string;
  fromUserId: string;
  fromName: string;
  toUserId: string;
  toName: string;
  message: string;
  read: boolean;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'follow-up' | 'inactive' | 'new-candidate' | 'status-change' | 'new-message';
  message: string;
  read: boolean;
  createdAt: string;
}

interface DataContextType {
  candidates: Candidate[];
  offers: Offer[];
  messages: Message[];
  notifications: Notification[];
  addCandidate: (candidate: Omit<Candidate, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateCandidate: (id: string, updates: Partial<Candidate>) => void;
  deleteCandidate: (id: string) => void;
  addOffer: (offer: Omit<Offer, 'id' | 'createdAt'>) => void;
  updateOffer: (id: string, updates: Partial<Offer>) => void;
  deleteOffer: (id: string) => void;
  sendMessage: (toUserId: string, toName: string, message: string) => void;
  markMessageAsRead: (id: string) => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  getAllUsers: () => any[];
  deleteUser: (userId: string) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    const storedCandidates = localStorage.getItem('talentBridge_candidates');
    if (storedCandidates) {
      setCandidates(JSON.parse(storedCandidates));
    }

    const storedOffers = localStorage.getItem('talentBridge_offers');
    if (storedOffers) {
      setOffers(JSON.parse(storedOffers));
    }

    const storedMessages = localStorage.getItem('talentBridge_messages');
    if (storedMessages) {
      setMessages(JSON.parse(storedMessages));
    }

    const storedNotifications = localStorage.getItem('talentBridge_notifications');
    if (storedNotifications) {
      setNotifications(JSON.parse(storedNotifications));
    }
  }, []);

  useEffect(() => {
    if (!user) return;

    const checkInactivity = () => {
      const users = JSON.parse(localStorage.getItem('talentBridge_users') || '[]');
      const now = new Date();

      users.forEach((u: any) => {
        if (u.role === 'recruiter' || u.role === 'team-leader') {
          const lastLogin = new Date(u.lastLogin || u.createdAt);
          const daysSinceLogin = Math.floor((now.getTime() - lastLogin.getTime()) / (1000 * 60 * 60 * 24));

          if (daysSinceLogin >= 3 && daysSinceLogin < 7) {
            const existingNotification = notifications.find(
              n => n.userId === u.id && n.type === 'follow-up' && !n.read
            );
            if (!existingNotification) {
              addNotification(u.id, 'follow-up', 'لم نراك منذ فترة! نتمنى أن تكون بخير. هل تحتاج أي مساعدة؟');
            }
          }

          if (u.role === 'recruiter' && daysSinceLogin >= 7) {
            const userCandidates = candidates.filter(c => c.recruiterId === u.id);
            const recentCandidates = userCandidates.filter(c => {
              const candidateDate = new Date(c.createdAt);
              const daysSinceCandidate = Math.floor((now.getTime() - candidateDate.getTime()) / (1000 * 60 * 60 * 24));
              return daysSinceCandidate <= 7;
            });

            if (recentCandidates.length === 0) {
              const existingNotification = notifications.find(
                n => n.userId === u.id && n.type === 'inactive' && !n.read
              );
              if (!existingNotification) {
                addNotification(u.id, 'inactive', 'لاحظنا أنك لم تسجل أي مرشحين مؤخراً. هل تواجه أي صعوبات؟ نحن هنا للمساعدة!');
              }
            }
          }
        }
      });
    };

    const interval = setInterval(checkInactivity, 60 * 60 * 1000);
    checkInactivity();

    return () => clearInterval(interval);
  }, [user, candidates, notifications]);

  const addNotification = (userId: string, type: Notification['type'], message: string) => {
    const newNotification: Notification = {
      id: `notification-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      userId,
      type,
      message,
      read: false,
      createdAt: new Date().toISOString()
    };

    const updatedNotifications = [...notifications, newNotification];
    setNotifications(updatedNotifications);
    localStorage.setItem('talentBridge_notifications', JSON.stringify(updatedNotifications));
  };

  const addCandidate = (candidate: Omit<Candidate, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newCandidate: Candidate = {
      ...candidate,
      id: `candidate-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const updatedCandidates = [...candidates, newCandidate];
    setCandidates(updatedCandidates);
    localStorage.setItem('talentBridge_candidates', JSON.stringify(updatedCandidates));

    if (candidate.teamLeaderId && user?.id !== candidate.teamLeaderId) {
      addNotification(
        candidate.teamLeaderId,
        'new-candidate',
        `تم إضافة مرشح جديد: ${newCandidate.name} للوظيفة: ${newCandidate.position}`
      );
    }
  };

  const updateCandidate = (id: string, updates: Partial<Candidate>) => {
    const updatedCandidates = candidates.map(c =>
      c.id === id ? { ...c, ...updates, updatedAt: new Date().toISOString() } : c
    );
    setCandidates(updatedCandidates);
    localStorage.setItem('talentBridge_candidates', JSON.stringify(updatedCandidates));

    if (updates.status) {
      const candidate = candidates.find(c => c.id === id);
      if (candidate) {
        addNotification(
          candidate.recruiterId,
          'status-change',
          `تم تحديث حالة المرشح ${candidate.name} إلى: ${updates.status}`
        );
      }
    }
  };

  const deleteCandidate = (id: string) => {
    const updatedCandidates = candidates.filter(c => c.id !== id);
    setCandidates(updatedCandidates);
    localStorage.setItem('talentBridge_candidates', JSON.stringify(updatedCandidates));
  };

  const addOffer = (offer: Omit<Offer, 'id' | 'createdAt'>) => {
    const newOffer: Offer = {
      ...offer,
      id: `offer-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date().toISOString()
    };

    const updatedOffers = [...offers, newOffer];
    setOffers(updatedOffers);
    localStorage.setItem('talentBridge_offers', JSON.stringify(updatedOffers));
  };

  const updateOffer = (id: string, updates: Partial<Offer>) => {
    const updatedOffers = offers.map(o => (o.id === id ? { ...o, ...updates } : o));
    setOffers(updatedOffers);
    localStorage.setItem('talentBridge_offers', JSON.stringify(updatedOffers));
  };

  const deleteOffer = (id: string) => {
    const updatedOffers = offers.filter(o => o.id !== id);
    setOffers(updatedOffers);
    localStorage.setItem('talentBridge_offers', JSON.stringify(updatedOffers));
  };

  const sendMessage = (toUserId: string, toName: string, message: string) => {
    if (!user) return;

    const newMessage: Message = {
      id: `message-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      fromUserId: user.id,
      fromName: user.role === 'co-founder' ? 'Talent Bridge Management' : user.name,
      toUserId,
      toName,
      message,
      read: false,
      createdAt: new Date().toISOString()
    };

    const updatedMessages = [...messages, newMessage];
    setMessages(updatedMessages);
    localStorage.setItem('talentBridge_messages', JSON.stringify(updatedMessages));

    addNotification(toUserId, 'new-message', `رسالة جديدة من ${newMessage.fromName}`);
  };

  const markMessageAsRead = (id: string) => {
    const updatedMessages = messages.map(m => (m.id === id ? { ...m, read: true } : m));
    setMessages(updatedMessages);
    localStorage.setItem('talentBridge_messages', JSON.stringify(updatedMessages));
  };

  const markNotificationAsRead = (id: string) => {
    const updatedNotifications = notifications.map(n => (n.id === id ? { ...n, read: true } : n));
    setNotifications(updatedNotifications);
    localStorage.setItem('talentBridge_notifications', JSON.stringify(updatedNotifications));
  };

  const markAllNotificationsAsRead = () => {
    if (!user) return;
    const updatedNotifications = notifications.map(n =>
      n.userId === user.id ? { ...n, read: true } : n
    );
    setNotifications(updatedNotifications);
    localStorage.setItem('talentBridge_notifications', JSON.stringify(updatedNotifications));
  };

  const getAllUsers = () => {
    return JSON.parse(localStorage.getItem('talentBridge_users') || '[]');
  };

  const deleteUser = (userId: string) => {
    const users = JSON.parse(localStorage.getItem('talentBridge_users') || '[]');
    const updatedUsers = users.filter((u: any) => u.id !== userId);
    localStorage.setItem('talentBridge_users', JSON.stringify(updatedUsers));

    const passwords = JSON.parse(localStorage.getItem('talentBridge_passwords') || '{}');
    delete passwords[userId];
    localStorage.setItem('talentBridge_passwords', JSON.stringify(passwords));

    const updatedCandidates = candidates.filter(c => c.recruiterId !== userId);
    setCandidates(updatedCandidates);
    localStorage.setItem('talentBridge_candidates', JSON.stringify(updatedCandidates));

    const updatedMessages = messages.filter(m => m.fromUserId !== userId && m.toUserId !== userId);
    setMessages(updatedMessages);
    localStorage.setItem('talentBridge_messages', JSON.stringify(updatedMessages));

    const updatedNotifications = notifications.filter(n => n.userId !== userId);
    setNotifications(updatedNotifications);
    localStorage.setItem('talentBridge_notifications', JSON.stringify(updatedNotifications));
  };

  return (
    <DataContext.Provider
      value={{
        candidates,
        offers,
        messages,
        notifications,
        addCandidate,
        updateCandidate,
        deleteCandidate,
        addOffer,
        updateOffer,
        deleteOffer,
        sendMessage,
        markMessageAsRead,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        getAllUsers,
        deleteUser
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}
